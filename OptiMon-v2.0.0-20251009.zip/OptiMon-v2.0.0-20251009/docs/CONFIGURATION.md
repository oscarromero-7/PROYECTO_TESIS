# Guía de Configuración OptiMon

## Configuración SMTP

### Gmail
```env
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=tu-email@gmail.com
SMTP_PASSWORD=tu-app-password
SMTP_FROM_EMAIL=tu-email@gmail.com
```

### Outlook/Hotmail
```env
SMTP_SERVER=smtp-mail.outlook.com
SMTP_PORT=587
SMTP_USERNAME=tu-email@outlook.com
SMTP_PASSWORD=tu-password
SMTP_FROM_EMAIL=tu-email@outlook.com
```

### Yahoo
```env
SMTP_SERVER=smtp.mail.yahoo.com
SMTP_PORT=587
SMTP_USERNAME=tu-email@yahoo.com
SMTP_PASSWORD=tu-app-password
SMTP_FROM_EMAIL=tu-email@yahoo.com
```

## Configuración de Alertas

### Destinatarios
Edita `config/email/recipients.json`:
```json
[
    {
        "name": "Admin Principal",
        "email": "admin@empresa.com",
        "alerts": ["critical", "warning"],
        "active": true
    },
    {
        "name": "Equipo DevOps",
        "email": "devops@empresa.com", 
        "alerts": ["critical"],
        "active": true
    }
]
```

### Umbrales de Alertas
Edita `config/prometheus/alert_rules.yml`:
```yaml
- alert: HighCPUUsage
  expr: cpu_usage > 80
  for: 5m
  
- alert: HighMemoryUsage
  expr: memory_usage > 90
  for: 3m
```

## Configuración de Infraestructura

### AWS (Opcional)
```env
AWS_ACCESS_KEY_ID=tu-access-key
AWS_SECRET_ACCESS_KEY=tu-secret-key
AWS_REGION=us-east-1
```

### Azure (Opcional)
```env
AZURE_CLIENT_ID=tu-client-id
AZURE_CLIENT_SECRET=tu-client-secret
AZURE_TENANT_ID=tu-tenant-id
AZURE_SUBSCRIPTION_ID=tu-subscription-id
```
