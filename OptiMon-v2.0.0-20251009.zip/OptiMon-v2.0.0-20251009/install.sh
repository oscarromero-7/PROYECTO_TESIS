#!/bin/bash

echo "==============================================="
echo "OptiMon v2.0 - Instalación Automática"
echo "==============================================="

# Verificar Python
echo "Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 no encontrado. Instala Python 3.8+ primero."
    exit 1
fi

# Verificar Docker
echo "Verificando Docker..."
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker no encontrado. Instala Docker primero."
    exit 1
fi

# Instalar dependencias
echo "Instalando dependencias Python..."
pip3 install -r requirements.txt

# Copiar configuraciones
echo "Verificando configuraciones..."
if [ ! -f "config/email/recipients.json" ]; then
    cp "config/email/recipients.example.json" "config/email/recipients.json"
fi

echo "IMPORTANTE: El archivo .env ya incluye credenciales SMTP funcionales"
echo "Si necesitas cambiar las credenciales, edita el archivo .env"

# Hacer ejecutables
chmod +x optimon/*.py
chmod +x tests/*.py

# Iniciar servicios Docker
echo "Iniciando servicios Docker..."
cd config/docker
docker-compose up -d
cd ../..

echo "==============================================="
echo "INSTALACIÓN COMPLETADA!"
echo "==============================================="
echo ""
echo "Servicios disponibles:"
echo "- Dashboard OptiMon: http://localhost:5000"
echo "- Grafana: http://localhost:3000 (admin/admin)"
echo "- Prometheus: http://localhost:9090"
echo "- AlertManager: http://localhost:9093"
echo ""
echo "Para iniciar OptiMon:"
echo "  python3 optimon/optimon_service_manager.py --daemon"
echo ""
echo "Para ejecutar tests:"
echo "  python3 tests/test_complete_system.py"
echo ""
