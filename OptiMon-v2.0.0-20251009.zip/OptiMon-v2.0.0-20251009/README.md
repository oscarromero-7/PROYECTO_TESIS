# OptiMon v2.0.0 - Sistema de Monitoreo Automatizado

## Descripción

OptiMon es un sistema completo de monitoreo de infraestructura que incluye:

- **Monitoreo automático** de servidores Windows/Linux
- **Sistema de alertas** por email configurable  
- **Dashboard web** con interfaz moderna
- **Gestión inteligente** de dashboards según infraestructura
- **Servicios automatizados** con recuperación ante fallos

## Instalación Rápida

### Windows
```cmd
INSTALL.bat
```

### Linux/Mac
```bash
chmod +x install.sh
./install.sh
```

### Instalación Manual

1. **Prerequisitos**
   - Python 3.8+
   - Docker y Docker Compose
   - Git (opcional)

2. **Instalar dependencias**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configurar variables de entorno (OPCIONAL)**
   ```bash
   # Las credenciales SMTP ya están configuradas
   # Si necesitas cambiarlas, edita .env
   ```

4. **Iniciar servicios Docker**
   ```bash
   cd config/docker
   docker-compose up -d
   cd ../..
   ```

5. **Iniciar OptiMon**
   ```bash
   python optimon/optimon_service_manager.py --daemon
   ```

## Acceso a Servicios

Una vez instalado, accede a:

- **Dashboard OptiMon**: http://localhost:5000
- **Grafana**: http://localhost:3000 (admin/admin)
- **Prometheus**: http://localhost:9090
- **AlertManager**: http://localhost:9093

## Configuración

**¡SMTP ya configurado!** El sistema incluye credenciales SMTP funcionales.

### 1. Gestionar Destinatarios de Alertas (REQUERIDO)

Via web: http://localhost:5000/emails

O edita manualmente: `config/email/recipients.json`

### 2. Cambiar Email SMTP (OPCIONAL)

Si necesitas usar tu propio email, edita el archivo `.env`:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=tu-email@gmail.com
SMTP_PASSWORD=tu-password-app
```

### 3. Monitoreo de Nube (Opcional)

Configura credenciales via web: http://localhost:5000/cloud

Los dashboards se crearán automáticamente.

## Testing

```bash
# Test completo del sistema
python tests/test_complete_system.py

# Test de destinatarios de email
python tests/test_recipients.py

# Test de alertas reales
python tests/test_real_alert.py
```

## Estructura del Paquete

```
OptiMon-v2.0.0/
├── optimon/                    # Servicios principales
├── config/                     # Configuraciones
├── infrastructure/             # Terraform (opcional)
├── scripts/                    # Scripts de utilidad
├── tests/                      # Tests del sistema
├── docs/                       # Documentación
├── INSTALL.bat                 # Instalador Windows
├── install.sh                  # Instalador Linux/Mac
└── README.md                   # Esta documentación
```

## Soporte

Para soporte y preguntas:
- GitHub: https://github.com/oscarromero-7/PROYECTO_TESIS
- Documentación: Ver directorio `docs/`

## Licencia

Este proyecto está bajo la Licencia MIT.
