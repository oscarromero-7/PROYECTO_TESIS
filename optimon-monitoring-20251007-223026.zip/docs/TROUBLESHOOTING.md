# OptiMon - Solucion de Problemas

## Problemas Comunes

### 1. Docker no inicia servicios
```bash
# Verificar estado de Docker
docker info

# Verificar logs
docker-compose logs -f prometheus
docker-compose logs -f grafana
```

### 2. No se conecta a VMs en la nube
- Verificar credenciales en archivos de configuracion
- Verificar permisos IAM/RBAC
- Verificar grupos de seguridad/NSG permiten SSH (puerto 22)

### 3. Node Exporter no se instala
- Verificar conectividad SSH a las maquinas
- Verificar permisos sudo del usuario SSH
- Verificar que las maquinas son Linux (Windows no soportado)

### 4. Grafana no muestra datos
- Verificar que Prometheus este ejecutandose: http://localhost:9090
- Verificar targets en Prometheus: http://localhost:9090/targets
- Verificar que Node Exporter este respondiendo en puerto 9100

### 5. Alertas no funcionan
- Verificar configuracion en config/alertmanager/alertmanager.yml
- Verificar reglas en config/prometheus/alert.rules.yml
- Verificar conectividad SMTP/webhook segun configuracion

## Comandos Utiles

### Ver todos los logs
```bash
docker-compose logs -f
```

### Reiniciar un servicio especifico
```bash
docker-compose restart prometheus
docker-compose restart grafana
```

### Reconstruir configuracion
```bash
python scripts/setup_prometheus.py
docker-compose restart prometheus
```

### Verificar conectividad a un servidor
```bash
ssh -o ConnectTimeout=10 usuario@ip_servidor
```

### Probar Node Exporter remoto
```bash
curl http://ip_servidor:9100/metrics
```

## Archivos de Log

Los logs se guardan en:
- `logs/optimon.log` - Log principal
- `logs/errors.log` - Solo errores
- `logs/access.log` - Accesos HTTP

## Contacto

Para soporte adicional:
- GitHub Issues: [Reportar problema](https://github.com/oscarromero-7/PROYECTO_TESIS/issues)
- Email: support@optimon.com
