# OptiMon - Guia de Inicio Rapido

## Instalacion SUPER FACIL en 3 pasos

### Paso 1: Configurar credenciales (SOLO esto)
```bash
# Editar el archivo de credenciales
# Solo necesitas completar las credenciales de tu proveedor de nube

# Para AWS - completar estos campos:
aws:
  access_key_id: "TU_AWS_ACCESS_KEY_ID"
  secret_access_key: "TU_AWS_SECRET_ACCESS_KEY"
  region: "us-east-1"

# Para Azure - completar estos campos:
azure:
  subscription_id: "TU_AZURE_SUBSCRIPTION_ID"
  tenant_id: "TU_AZURE_TENANT_ID"
  client_id: "TU_AZURE_CLIENT_ID"
  client_secret: "TU_AZURE_CLIENT_SECRET"
```

### Paso 2: Ejecutar TODO automaticamente
```bash
# Linux/Mac
./deploy.sh

# Windows
.\deploy.ps1
```

### Paso 3: Acceder y monitorear
- Grafana: http://localhost:3000 (admin/admin)
- Prometheus: http://localhost:9090
- AlertManager: http://localhost:9093

## ESO ES TODO!

El sistema automaticamente:
- Detecta todas tus VMs/instancias
- Encuentra las claves SSH correctas  
- Instala Node Exporter en cada servidor
- Configura Prometheus y Grafana
- Inicia el monitoreo completo

## Que hace automaticamente

### Deteccion inteligente:
- Encuentra todas las VMs en ejecucion
- Detecta el usuario SSH correcto por tipo de OS
- Busca claves SSH en ubicaciones comunes
- Determina IPs publicas/privadas disponibles

### Instalacion automatica:
- Instala Node Exporter en paralelo
- Configura servicios systemd
- Actualiza configuracion de Prometheus
- Crea dashboards personalizados

### Sin configuracion manual:
- No necesitas especificar IPs
- No necesitas configurar SSH
- No necesitas usuarios o puertos
- No necesitas claves SSH manuales

## Solucion de Problemas

### Si no detecta instancias:
- Verifica credenciales de nube
- Verifica que las VMs esten ejecutandose
- Verifica permisos IAM/RBAC

### Si no se conecta por SSH:
- El sistema probara usuarios comunes automaticamente
- Buscara claves SSH en ubicaciones estandar
- Intentara multiples metodos de conexion

### Ver que esta pasando:
```bash
# Ver logs detallados
docker-compose logs -f

# Ver targets de Prometheus
http://localhost:9090/targets

# Probar conectividad manual
ssh usuario@ip_instancia
```
