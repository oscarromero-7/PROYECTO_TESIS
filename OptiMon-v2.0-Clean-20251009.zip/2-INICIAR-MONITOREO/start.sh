#!/bin/bash
echo "🚀 Iniciando OptiMon..."
docker-compose up -d
echo "✅ ¡Listo! Accede a tu dashboard en http://localhost:3000"
echo "    (Usuario/Contraseña por defecto: admin/admin)"
