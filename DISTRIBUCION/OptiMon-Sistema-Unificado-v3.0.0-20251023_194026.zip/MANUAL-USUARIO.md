# OptiMon Sistema Unificado - Manual de Usuario
Versión: 3.0.0-UNIFIED

## 🚀 Instalación Rápida

### Windows
1. Extraer OptiMon-Sistema-Unificado-*.zip
2. Ejecutar como administrador: `install-windows.bat`
3. Abrir navegador en: http://localhost:5000

### Linux/macOS
1. Extraer OptiMon-Sistema-Unificado-*.zip
2. Ejecutar: `chmod +x install-linux.sh && ./install-linux.sh`
3. Abrir navegador en: http://localhost:5000

## 📋 Requisitos Previos

### Software Necesario
- **Docker Desktop**: https://www.docker.com/products/docker-desktop
- **Python 3.11+**: https://www.python.org/downloads/
- **PowerShell** (Windows) o **Bash** (Linux/macOS)

### Hardware Mínimo
- **RAM**: 4GB disponibles
- **Disco**: 2GB espacio libre
- **CPU**: 2 cores mínimo
- **Red**: Conexión a Internet para contenedores

## 🌐 Accesos del Sistema

| Servicio | URL | Usuario | Contraseña |
|----------|-----|---------|------------|
| **Portal OptiMon** | http://localhost:5000 | - | - |
| **Grafana** | http://localhost:3000 | admin | admin |
| **Prometheus** | http://localhost:9090 | - | - |
| **AlertManager** | http://localhost:9093 | - | - |

## ⚙️ Configuración Inicial

### 1. Configurar Emails (Opcional)
1. Acceder al Portal: http://localhost:5000
2. Click en "Email Configuration"
3. Ingresar credenciales SMTP
4. Agregar destinatarios
5. Click "Guardar Configuración"

### 2. Configurar Cloud (Opcional)
1. Acceder al Portal: http://localhost:5000
2. Click en "Cloud Configuration" 
3. Agregar credenciales AWS y/o Azure
4. Click "Guardar Credenciales"
5. Click "Descubrir VMs"

### 3. Verificar Sistema Local
1. El sistema se configura automáticamente
2. Windows Exporter se instala solo
3. Dashboard local disponible inmediatamente

## 🔧 Configuración Avanzada

### SSH Keys Auto-Detection
El sistema busca automáticamente claves SSH en:
- `~/.ssh/` - Directorio SSH estándar
- `~/Downloads/` - Carpeta de descargas
- `~/Desktop/` - Escritorio
- `./keys/` - Directorio local

### Usuarios SSH Probados
- **Cloud**: azureuser, ec2-user, ubuntu
- **Estándar**: admin, root, user
- **Distribuciones**: centos, debian, fedora
- **Especiales**: bitnami, oracle, deploy

### Configurar Alertas Personalizadas
1. Editar: `docker/prometheus/alert.rules.yml`
2. Reiniciar: `docker compose restart prometheus`
3. Verificar en AlertManager

## 🐛 Solución de Problemas

### Docker no inicia
```bash
# Windows
Restart-Service Docker

# Linux
sudo systemctl restart docker
```

### Puerto ocupado
```bash
# Encontrar proceso
netstat -ano | findstr :5000

# Terminar proceso
taskkill /PID <PID> /F
```

### Python no encontrado
```bash
# Verificar instalación
python --version
python3 --version

# Si no existe, descargar desde:
# https://www.python.org/downloads/
```

### Servicios no inician
```bash
# Verificar Docker Compose
docker compose ps

# Reiniciar servicios
docker compose down
docker compose up -d
```

## 📊 Dashboards Disponibles

### Sistema Local
- CPU, RAM, Disk en tiempo real
- Alertas configuradas automáticamente
- Histórico de métricas

### Cloud Infrastructure  
- AWS EC2 instances
- Azure Virtual Machines
- Estado de Node Exporters

### Alertas Activas
- CPU > 80%
- RAM > 85% 
- Disk > 90%
- Servicios caídos

## 🔐 Seguridad

- Credenciales almacenadas localmente
- Conexiones SSH cifradas
- No transmisión de claves privadas
- APIs cloud con autenticación oficial

## 📞 Soporte

- **Portal**: http://localhost:5000/help
- **Status**: http://localhost:5000/api/health
- **SSH Keys**: http://localhost:5000/api/ssh-keys
- **Email**: Proyecto20251985@hotmail.com

---
OptiMon Sistema Unificado v3.0.0-UNIFIED
© 2025 - Proyecto Académico
