# 🚀 OptiMon - Inicio Rápido (5 minutos)

## ✅ Verificación Previa (1 minuto)

### ¿Tienes Docker?
```bash
docker --version
```
❌ **Si no**: Descargar desde https://www.docker.com/products/docker-desktop

### ¿Tienes Python?
```bash
python --version
```
❌ **Si no**: Descargar desde https://www.python.org/downloads/

## 🎯 Instalación Express (2 minutos)

### Windows
```cmd
# Extraer ZIP y ejecutar:
install-windows.bat
```

### Linux/macOS  
```bash
# Extraer ZIP y ejecutar:
chmod +x install-linux.sh
./install-linux.sh
```

## 🌐 Acceso Inmediato (30 segundos)

Abrir navegador en:
- **🎛️ Portal Principal**: http://localhost:5000
- **📊 Grafana**: http://localhost:3000 (admin/admin)

## ⚙️ Configuración Opcional (2 minutos)

### Email Alerts
1. Portal → Email Config
2. Ingresar SMTP (Outlook recomendado)
3. Agregar destinatarios

### Cloud Monitoring
1. Portal → Cloud Config  
2. Agregar credenciales AWS/Azure
3. Click "Descubrir VMs"

## ✅ ¡Listo!

Tu sistema ya está monitoreando:
- ✅ PC local (automático)
- ✅ Dashboards disponibles
- ✅ Alertas configuradas
- ✅ Cloud (si configuraste)

---
**¿Problemas?** Ver TROUBLESHOOTING.md
**¿Preguntas?** Ver MANUAL-USUARIO.md
