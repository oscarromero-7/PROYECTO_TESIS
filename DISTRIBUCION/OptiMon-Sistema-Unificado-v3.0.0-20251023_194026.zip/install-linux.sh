#!/bin/bash

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "=========================================="
echo "  OptiMon Sistema Unificado v3.0.0"
echo "  Instalador Automatico Linux/macOS"
echo "=========================================="
echo -e "${NC}"

# Verificar Docker
echo -e "${YELLOW}[1/6] Verificando Docker...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ ERROR: Docker no encontrado${NC}"
    echo -e "${YELLOW}Por favor instalar Docker desde: https://docs.docker.com/get-docker/${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Docker encontrado${NC}"

# Verificar Python
echo -e "${YELLOW}[2/6] Verificando Python...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ ERROR: Python3 no encontrado${NC}"
    echo -e "${YELLOW}Por favor instalar Python 3.11+ desde: https://www.python.org/downloads/${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Python encontrado${NC}"

# Instalar dependencias
echo -e "${YELLOW}[3/6] Instalando dependencias Python...${NC}"
python3 -m pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ ERROR: Fallo instalación dependencias${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Dependencias instaladas${NC}"

# Iniciar servicios Docker
echo -e "${YELLOW}[4/6] Iniciando servicios Docker...${NC}"
docker compose up -d
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ ERROR: Fallo inicio Docker services${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Servicios Docker iniciados${NC}"

# Configurar .env
echo -e "${YELLOW}[5/6] Configurando archivo .env...${NC}"
if [ ! -f ".env" ]; then
    cp ".env.example" ".env"
    echo -e "${GREEN}✅ Archivo .env creado${NC}"
else
    echo -e "${GREEN}✅ Archivo .env ya existe${NC}"
fi

# Iniciar aplicación
echo -e "${YELLOW}[6/6] Iniciando OptiMon Portal...${NC}"

echo -e "${BLUE}"
echo "=========================================="
echo "  ✅ INSTALACION COMPLETADA"
echo ""
echo "  Accesos del sistema:"
echo "  📱 Portal Principal: http://localhost:5000"
echo "  📊 Grafana:         http://localhost:3000"  
echo "  📈 Prometheus:      http://localhost:9090"
echo "  🚨 AlertManager:    http://localhost:9093"
echo ""
echo "  Iniciando aplicacion..."
echo "=========================================="
echo -e "${NC}"

# Abrir navegador (si está disponible)
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:5000 &
elif command -v open &> /dev/null; then
    open http://localhost:5000 &
fi

python3 app.py
