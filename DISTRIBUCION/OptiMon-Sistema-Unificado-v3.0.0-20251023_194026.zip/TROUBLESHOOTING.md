# OptiMon - Guía de Solución de Problemas

## 🚨 Problemas Comunes

### 1. Error "Docker no encontrado"
**Síntoma**: `docker: command not found`
**Solución**:
1. Instalar Docker Desktop
2. Asegurarse que Docker está ejecutándose
3. Reiniciar terminal/PowerShell

### 2. Error "Puerto 5000 ocupado"
**Síntoma**: `Address already in use`
**Solución**:
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/macOS
lsof -ti:5000 | xargs kill -9
```

### 3. Error "Python no encontrado"
**Síntoma**: `python: command not found`
**Solución**:
1. Instalar Python 3.11+
2. Agregar Python al PATH
3. Usar `python3` en lugar de `python`

### 4. Servicios Docker no inician
**Síntoma**: Containers en estado "Exited"
**Solución**:
```bash
docker compose down
docker compose up -d
docker compose logs
```

### 5. Windows Exporter no funciona
**Síntoma**: No aparecen métricas locales
**Solución**:
1. Ejecutar como administrador
2. Verificar puerto 9182
3. Reiniciar sistema si es necesario

## 🔧 Comandos de Diagnóstico

### Verificar Estado del Sistema
```bash
# Estado Docker
docker compose ps

# Logs de servicios
docker compose logs prometheus
docker compose logs grafana

# Estado de puertos
netstat -ano | findstr "5000 3000 9090 9093"

# Verificar Python
python --version
pip list | findstr "flask prometheus psutil"
```

### Verificar Conectividad
```bash
# Portal OptiMon
curl http://localhost:5000/api/health

# Prometheus
curl http://localhost:9090/-/healthy

# Grafana
curl http://localhost:3000/api/health
```

## 📊 Logs Importantes

### Ubicaciones de Logs
- **OptiMon**: `logs/optimon.log`
- **Docker Compose**: `docker compose logs`
- **Windows**: Event Viewer > Applications
- **Linux**: `/var/log/syslog`

### Comandos de Log
```bash
# Ver logs OptiMon
tail -f logs/optimon.log

# Ver logs Docker en tiempo real
docker compose logs -f

# Ver logs específico
docker compose logs prometheus
```

## 🌐 Problemas de Red

### Proxy/Firewall
Si estás detrás de proxy corporativo:
1. Configurar Docker con proxy
2. Configurar pip con proxy
3. Abrir puertos en firewall

### DNS Issues
```bash
# Verificar resolución DNS
nslookup docker.io
ping 8.8.8.8
```

## 💾 Recuperación de Datos

### Backup de Configuración
```bash
# Respaldar configuraciones
cp -r docker/prometheus ./backup/
cp -r docker/grafana ./backup/
cp config/*.json ./backup/
```

### Restaurar Sistema
```bash
# Limpiar todo
docker compose down -v
docker system prune -af

# Restaurar y reiniciar
docker compose up -d
```

## 🔄 Actualización del Sistema

### Actualizar OptiMon
1. Descargar nueva versión
2. Backup configuraciones
3. Extraer nueva versión
4. Copiar configuraciones antiguas
5. Ejecutar instalador

### Actualizar Docker Images
```bash
docker compose pull
docker compose up -d
```

## 📞 Obtener Ayuda

### Información del Sistema
1. Acceder a: http://localhost:5000/api/health
2. Capturar screenshot del error
3. Copiar logs relevantes
4. Incluir versión del OS

### Reportar Problemas
- **Email**: Proyecto20251985@hotmail.com
- **Incluir**: OS, Python version, Docker version
- **Adjuntar**: Logs y screenshots

---
Última actualización: $(date)
