# OptiMon Deployment Script para Windows
# Automated deployment for infrastructure monitoring

param(
    [switch]$SkipCredentials,
    [switch]$Verbose
)

# Configurar colores para salida
$Host.UI.RawUI.BackgroundColor = "Black"
$ErrorActionPreference = "Stop"

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White",
        [string]$Emoji = ""
    )
    
    if ($Emoji) {
        Write-Host "$Emoji $Message" -ForegroundColor $Color
    } else {
        Write-Host $Message -ForegroundColor $Color
    }
}

function Write-Header {
    Write-ColorOutput "🚀 OptiMon - Sistema de Monitoreo de Infraestructura" "Cyan"
    Write-ColorOutput "==================================================" "Cyan"
    Write-Host ""
}

function Test-Prerequisites {
    Write-ColorOutput "📋 Verificando prerrequisitos..." "Yellow"
    
    # Verificar Docker
    try {
        $dockerVersion = docker --version 2>$null
        if (-not $dockerVersion) {
            throw "Docker no encontrado"
        }
        Write-ColorOutput "✅ Docker está instalado: $dockerVersion" "Green"
    }
    catch {
        Write-ColorOutput "❌ Docker no está instalado" "Red"
        Write-ColorOutput "Por favor instala Docker Desktop antes de continuar" "Red"
        exit 1
    }
    
    # Verificar Docker Compose
    try {
        $composeVersion = docker-compose --version 2>$null
        if (-not $composeVersion) {
            throw "Docker Compose no encontrado"
        }
        Write-ColorOutput "✅ Docker Compose está instalado: $composeVersion" "Green"
    }
    catch {
        Write-ColorOutput "❌ Docker Compose no está instalado" "Red"
        Write-ColorOutput "Por favor instala Docker Compose antes de continuar" "Red"
        exit 1
    }
    
    # Verificar Python
    try {
        $pythonVersion = python --version 2>$null
        if (-not $pythonVersion) {
            $pythonVersion = python3 --version 2>$null
        }
        if (-not $pythonVersion) {
            throw "Python no encontrado"
        }
        Write-ColorOutput "✅ Python está instalado: $pythonVersion" "Green"
    }
    catch {
        Write-ColorOutput "❌ Python no está instalado" "Red"
        Write-ColorOutput "Por favor instala Python 3.8+ antes de continuar" "Red"
        exit 1
    }
    
    Write-ColorOutput "✅ Todos los prerrequisitos están instalados" "Green"
    Write-Host ""
}

function Install-PythonDependencies {
    Write-ColorOutput "📦 Instalando dependencias Python..." "Yellow"
    
    if (Test-Path "requirements.txt") {
        try {
            & python -m pip install -r requirements.txt
            Write-ColorOutput "✅ Dependencias Python instaladas" "Green"
        }
        catch {
            Write-ColorOutput "⚠️  Error instalando dependencias Python" "Yellow"
        }
    } else {
        Write-ColorOutput "⚠️  Archivo requirements.txt no encontrado" "Yellow"
    }
    Write-Host ""
}

function Setup-Credentials {
    if ($SkipCredentials) {
        Write-ColorOutput "⏭️  Saltando configuración de credenciales" "Yellow"
        return
    }
    
    Write-ColorOutput "🔐 Configurando credenciales..." "Yellow"
    
    $awsCredentials = Test-Path "config/aws-credentials.yml"
    $azureCredentials = Test-Path "config/azure-credentials.yml"
    
    if (-not $awsCredentials -and -not $azureCredentials) {
        Write-ColorOutput "⚠️  No se encontraron archivos de credenciales" "Yellow"
        Write-Host "Por favor configura al menos uno:"
        Write-Host "  - config/aws-credentials.yml (para AWS)"
        Write-Host "  - config/azure-credentials.yml (para Azure)"
        Write-Host ""
        Write-Host "Usa el archivo config/credentials.example.yml como plantilla"
        
        $continue = Read-Host "¿Quieres continuar sin credenciales de nube? (y/N)"
        if ($continue -ne "y" -and $continue -ne "Y") {
            exit 1
        }
    } else {
        Write-ColorOutput "✅ Archivos de credenciales encontrados" "Green"
    }
    Write-Host ""
}

function Setup-Prometheus {
    Write-ColorOutput "⚙️  Configurando Prometheus..." "Yellow"
    
    if (-not (Test-Path "config/prometheus/prometheus.yml")) {
        Write-ColorOutput "📝 Creando configuración inicial de Prometheus" "Cyan"
        & python scripts/setup_prometheus.py
    }
    
    Write-ColorOutput "✅ Prometheus configurado" "Green"
    Write-Host ""
}

function Start-Services {
    Write-ColorOutput "🐳 Iniciando servicios Docker..." "Yellow"
    
    # Detener servicios existentes si están corriendo
    try {
        & docker-compose down 2>$null
    }
    catch {
        # Ignorar errores si no hay servicios corriendo
    }
    
    # Construir e iniciar servicios
    & docker-compose up -d
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "✅ Servicios iniciados exitosamente" "Green"
    } else {
        Write-ColorOutput "❌ Error iniciando servicios Docker" "Red"
        exit 1
    }
    Write-Host ""
}

function Test-Services {
    Write-ColorOutput "🔍 Verificando servicios..." "Yellow"
    
    # Esperar unos segundos para que los servicios inicien
    Start-Sleep -Seconds 10
    
    $services = @(
        @{Name = "Prometheus"; Port = 9090},
        @{Name = "Grafana"; Port = 3000},
        @{Name = "AlertManager"; Port = 9093}
    )
    
    foreach ($service in $services) {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:$($service.Port)" -TimeoutSec 5 -ErrorAction Stop
            Write-ColorOutput "✅ $($service.Name) está funcionando en puerto $($service.Port)" "Green"
        }
        catch {
            Write-ColorOutput "❌ $($service.Name) no responde en puerto $($service.Port)" "Red"
        }
    }
    Write-Host ""
}

function Start-AutoDiscovery {
    Write-ColorOutput "🔍 Descubriendo infraestructura..." "Yellow"
    
    if (Test-Path "config/aws-credentials.yml") {
        Write-ColorOutput "🔄 Configurando monitoreo AWS..." "Cyan"
        & python scripts/setup_aws_monitoring.py
    }
    
    if (Test-Path "config/azure-credentials.yml") {
        Write-ColorOutput "🔄 Configurando monitoreo Azure..." "Cyan"
        & python scripts/setup_azure_monitoring.py
    }
    
    Write-ColorOutput "✅ Configuración automática completada" "Green"
    Write-Host ""
}

function Show-FinalInfo {
    Write-Host ""
    Write-ColorOutput "🎉 ¡Despliegue completado exitosamente!" "Green"
    Write-ColorOutput "======================================" "Green"
    Write-Host ""
    Write-ColorOutput "📊 Accede a los servicios:" "Cyan"
    Write-Host "  • Grafana:      http://localhost:3000 (admin/admin)"
    Write-Host "  • Prometheus:   http://localhost:9090"
    Write-Host "  • AlertManager: http://localhost:9093"
    Write-Host ""
    Write-ColorOutput "🛠️  Comandos útiles:" "Cyan"
    Write-Host "  • Ver logs:           docker-compose logs -f"
    Write-Host "  • Detener servicios:  docker-compose down"
    Write-Host "  • Reiniciar:          docker-compose restart"
    Write-Host "  • Añadir servidor:    .\scripts\add_server.ps1"
    Write-Host ""
    Write-ColorOutput "📖 Para más información, consulta README.md" "Yellow"
}

function Main {
    try {
        Write-Header
        Test-Prerequisites
        Install-PythonDependencies
        Setup-Credentials
        Setup-Prometheus
        Start-Services
        Test-Services
        Start-AutoDiscovery
        Show-FinalInfo
    }
    catch {
        Write-ColorOutput "❌ Error durante el despliegue: $($_.Exception.Message)" "Red"
        exit 1
    }
}

# Ejecutar función principal
Main