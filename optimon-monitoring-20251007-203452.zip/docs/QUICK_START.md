# OptiMon - Guia de Inicio Rapido

## Instalacion en 5 minutos

### Paso 1: Prerrequisitos
```bash
# Verificar Docker
docker --version
docker-compose --version

# Verificar Python
python --version  # o python3 --version
```

### Paso 2: Configurar credenciales
```bash
# Para AWS
cp config/credentials.example.yml config/aws-credentials.yml
# Editar aws-credentials.yml con tus credenciales

# Para Azure  
cp config/credentials.example.yml config/azure-credentials.yml
# Editar azure-credentials.yml con tus credenciales
```

### Paso 3: Desplegar
```bash
# Linux/Mac
./deploy.sh

# Windows
.\deploy.ps1
```

### Paso 4: Acceder
- Grafana: http://localhost:3000 (admin/admin)
- Prometheus: http://localhost:9090
- AlertManager: http://localhost:9093

## Configuracion Manual

### Anadir servidor fisico
```bash
./add_server.sh  # Linux/Mac
.dd_server.ps1  # Windows
```

### Personalizar alertas
Editar `config/alertmanager/alertmanager.yml`

### Anadir dashboards
Colocar archivos JSON en `config/grafana/dashboards/`

## Solucion de Problemas

### Servicios no inician
```bash
docker-compose logs -f
```

### Credenciales incorrectas
Verificar formato YAML en archivos de configuracion

### Puertos ocupados
Cambiar puertos en docker-compose.yml
