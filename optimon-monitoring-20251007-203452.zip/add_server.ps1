# Script para añadir servidores físicos al monitoreo

Write-Host "OptiMon - Añadir Servidor Físico" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

$serverName = Read-Host "Nombre del servidor"
$serverIP = Read-Host "Dirección IP"
$sshUser = Read-Host "Usuario SSH"
$sshPort = Read-Host "Puerto SSH (22)"
if ([string]::IsNullOrEmpty($sshPort)) { $sshPort = "22" }

Write-Host "Selecciona método de autenticación:"
Write-Host "1) Clave SSH"
Write-Host "2) Contraseña"
$authMethod = Read-Host "Opción (1-2)"

if ($authMethod -eq "1") {
    $keyFile = Read-Host "Ruta a la clave privada"
    & python scripts/add_physical_server.py --name $serverName --ip $serverIP --user $sshUser --port $sshPort --key $keyFile
} else {
    $sshPass = Read-Host "Contraseña SSH" -AsSecureString
    $plainPass = [System.Net.NetworkCredential]::new("", $sshPass).Password
    & python scripts/add_physical_server.py --name $serverName --ip $serverIP --user $sshUser --port $sshPort --password $plainPass
}
