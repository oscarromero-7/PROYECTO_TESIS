# OptiMon - Sistema de Monitoreo de Infraestructura

Sistema completo de monitoreo para infraestructura en la nube (AWS/Azure) y servidores físicos usando Prometheus, Grafana y Node Exporter.

## 🚀 Características

- **Monitoreo Multi-Plataforma**: AWS, Azure y servidores físicos
- **Instalación Automática**: Despliega Node Exporter automáticamente
- **Dashboards Preconfiguratos**: Grafana con métricas listas para usar
- **Alertas Inteligentes**: Notificaciones automáticas de problemas
- **Fácil Configuración**: Solo necesitas credenciales de nube

## 📋 Prerrequisitos

- Docker y Docker Compose instalados
- Python 3.8+ (para scripts de configuración)
- Credenciales de AWS o Azure (según corresponda)
- Conectividad SSH a servidores físicos

## 🛠️ Instalación Rápida

### 1. Descomprimir y navegar
```bash
unzip optimon-monitoring.zip
cd optimon-monitoring
```

### 2. Configurar credenciales
```bash
# Para AWS
cp config/credentials.example.yml config/aws-credentials.yml
# Editar con tus credenciales

# Para Azure
cp config/credentials.example.yml config/azure-credentials.yml
# Editar con tus credenciales
```

### 3. Iniciar el sistema
```bash
./deploy.sh
```

### 4. Acceder a los servicios
- **Grafana**: http://localhost:3000 (admin/admin)
- **Prometheus**: http://localhost:9090
- **AlertManager**: http://localhost:9093

## 📊 Uso

### Monitoreo de Nube (AWS/Azure)
1. El sistema detecta automáticamente las VMs en tu cuenta
2. Instala Node Exporter en cada VM
3. Configura Prometheus para recopilar métricas

### Monitoreo de Servidores Físicos
1. Agrega servidores manualmente con `./add-server.sh`
2. Proporciona IP, usuario y credenciales SSH
3. El sistema instala y configura automáticamente

## 🔧 Configuración Avanzada

### Personalizar Dashboards
- Edita archivos en `grafana/dashboards/`
- Reinicia Grafana: `docker-compose restart grafana`

### Añadir Alertas
- Modifica `prometheus/alert.rules.yml`
- Configura notificaciones en `alertmanager/alertmanager.yml`

## 📁 Estructura del Proyecto

```
optimon-monitoring/
├── docker-compose.yml          # Configuración principal
├── deploy.sh                   # Script de despliegue
├── config/                     # Configuraciones
│   ├── credentials.example.yml
│   ├── prometheus/
│   ├── grafana/
│   └── alertmanager/
├── scripts/                    # Scripts de automatización
│   ├── setup_cloud.py
│   ├── install_node_exporter.py
│   └── server_manager.py
└── docs/                       # Documentación adicional
```

## 🆘 Solución de Problemas

### Problemas comunes
1. **Docker no funciona**: Verificar que Docker esté iniciado
2. **No se conecta a VMs**: Revisar credenciales y permisos
3. **Grafana no muestra datos**: Verificar configuración de Prometheus

### Logs
```bash
# Ver logs de todos los servicios
docker-compose logs -f

# Ver logs de un servicio específico
docker-compose logs -f prometheus
```

## 🔒 Seguridad

- Las credenciales se almacenan localmente
- Comunicación SSH encriptada
- Tokens temporales para APIs de nube
- Configuración de firewall recomendada

## 📈 Métricas Disponibles

### Métricas del Sistema
- CPU, Memoria, Disco
- Red, Procesos
- Temperatura, Hardware

### Métricas de Nube
- Estados de VMs
- Costos estimados
- Alertas de servicio

### Alertas Preconfiguratas
- CPU > 80%
- Memoria > 90%
- Disco > 85%
- Servicio no disponible

## 🤝 Contribuir

1. Fork del proyecto
2. Crear rama feature
3. Commit cambios
4. Push a la rama
5. Abrir Pull Request

## 📄 Licencia

MIT License - ver archivo LICENSE

## 📞 Soporte

- Email: support@optimon.com
- GitHub Issues: [Reportar problema](https://github.com/oscarromero-7/PROYECTO_TESIS/issues)
- Documentación: [Wiki del proyecto](https://github.com/oscarromero-7/PROYECTO_TESIS/wiki)