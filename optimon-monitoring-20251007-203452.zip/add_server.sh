#!/bin/bash
# Script para a�adir servidores f�sicos al monitoreo

echo "OptiMon - A�adir Servidor F�sico"
echo "================================="

read -p "Nombre del servidor: " SERVER_NAME
read -p "Direcci�n IP: " SERVER_IP
read -p "Usuario SSH: " SSH_USER
read -p "Puerto SSH (22): " SSH_PORT
SSH_PORT=${SSH_PORT:-22}

echo "Selecciona m�todo de autenticaci�n:"
echo "1) Clave SSH"
echo "2) Contrase�a"
read -p "Opci�n (1-2): " AUTH_METHOD

if [ "$AUTH_METHOD" = "1" ]; then
    read -p "Ruta a la clave privada: " KEY_FILE
    python3 scripts/add_physical_server.py --name "$SERVER_NAME" --ip "$SERVER_IP" --user "$SSH_USER" --port "$SSH_PORT" --key "$KEY_FILE"
else
    read -s -p "Contrase�a SSH: " SSH_PASS
    echo
    python3 scripts/add_physical_server.py --name "$SERVER_NAME" --ip "$SERVER_IP" --user "$SSH_USER" --port "$SSH_PORT" --password "$SSH_PASS"
fi
